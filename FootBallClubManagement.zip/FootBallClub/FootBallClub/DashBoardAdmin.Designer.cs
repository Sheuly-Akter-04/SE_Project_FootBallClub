﻿namespace FootBallClub
{
    partial class DashBoardAdmin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panelSideMenu = new System.Windows.Forms.Panel();
            this.btnOtherNewDown = new System.Windows.Forms.Button();
            this.panelPresidentsDemo = new System.Windows.Forms.Panel();
            this.button5 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.panelOthersDown = new System.Windows.Forms.Panel();
            this.button11 = new System.Windows.Forms.Button();
            this.button10 = new System.Windows.Forms.Button();
            this.btnTeamEditOrShow = new System.Windows.Forms.Button();
            this.btnOthersDown = new System.Windows.Forms.Button();
            this.panelStaff1Demo = new System.Windows.Forms.Panel();
            this.btnCoachUpdateOrDelete = new System.Windows.Forms.Button();
            this.btnAddCourseByAdmin = new System.Windows.Forms.Button();
            this.buttonSeeCoach = new System.Windows.Forms.Button();
            this.btnStaffDemo1 = new System.Windows.Forms.Button();
            this.panelDown1SubMenu = new System.Windows.Forms.Panel();
            this.button1 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.btnRegistrationDemo = new System.Windows.Forms.Button();
            this.btnPlayerSeeAll = new System.Windows.Forms.Button();
            this.btnDown1 = new System.Windows.Forms.Button();
            this.panelLogo = new System.Windows.Forms.Panel();
            this.panelChild1DashBoardAdmin = new System.Windows.Forms.Panel();
            this.panelSideMenu.SuspendLayout();
            this.panelPresidentsDemo.SuspendLayout();
            this.panelOthersDown.SuspendLayout();
            this.panelStaff1Demo.SuspendLayout();
            this.panelDown1SubMenu.SuspendLayout();
            this.SuspendLayout();
            // 
            // panelSideMenu
            // 
            this.panelSideMenu.AutoScroll = true;
            this.panelSideMenu.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.panelSideMenu.Controls.Add(this.btnOtherNewDown);
            this.panelSideMenu.Controls.Add(this.panelPresidentsDemo);
            this.panelSideMenu.Controls.Add(this.panelOthersDown);
            this.panelSideMenu.Controls.Add(this.btnOthersDown);
            this.panelSideMenu.Controls.Add(this.panelStaff1Demo);
            this.panelSideMenu.Controls.Add(this.btnStaffDemo1);
            this.panelSideMenu.Controls.Add(this.panelDown1SubMenu);
            this.panelSideMenu.Controls.Add(this.btnDown1);
            this.panelSideMenu.Controls.Add(this.panelLogo);
            this.panelSideMenu.Dock = System.Windows.Forms.DockStyle.Left;
            this.panelSideMenu.Location = new System.Drawing.Point(0, 0);
            this.panelSideMenu.Name = "panelSideMenu";
            this.panelSideMenu.Size = new System.Drawing.Size(208, 509);
            this.panelSideMenu.TabIndex = 0;
            // 
            // btnOtherNewDown
            // 
            this.btnOtherNewDown.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.btnOtherNewDown.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnOtherNewDown.Location = new System.Drawing.Point(0, 650);
            this.btnOtherNewDown.Name = "btnOtherNewDown";
            this.btnOtherNewDown.Size = new System.Drawing.Size(191, 40);
            this.btnOtherNewDown.TabIndex = 9;
            this.btnOtherNewDown.Text = "Others";
            this.btnOtherNewDown.UseVisualStyleBackColor = false;
            this.btnOtherNewDown.Click += new System.EventHandler(this.BtnOtherNewDown_Click);
            // 
            // panelPresidentsDemo
            // 
            this.panelPresidentsDemo.Controls.Add(this.button5);
            this.panelPresidentsDemo.Controls.Add(this.button3);
            this.panelPresidentsDemo.Controls.Add(this.button2);
            this.panelPresidentsDemo.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelPresidentsDemo.Location = new System.Drawing.Point(0, 515);
            this.panelPresidentsDemo.Name = "panelPresidentsDemo";
            this.panelPresidentsDemo.Size = new System.Drawing.Size(191, 135);
            this.panelPresidentsDemo.TabIndex = 8;
            // 
            // button5
            // 
            this.button5.Dock = System.Windows.Forms.DockStyle.Top;
            this.button5.Location = new System.Drawing.Point(0, 80);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(191, 40);
            this.button5.TabIndex = 9;
            this.button5.Text = "Update or delete";
            this.button5.UseVisualStyleBackColor = true;
            // 
            // button3
            // 
            this.button3.Dock = System.Windows.Forms.DockStyle.Top;
            this.button3.Location = new System.Drawing.Point(0, 40);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(191, 40);
            this.button3.TabIndex = 8;
            this.button3.Text = "Add new";
            this.button3.UseVisualStyleBackColor = true;
            // 
            // button2
            // 
            this.button2.Dock = System.Windows.Forms.DockStyle.Top;
            this.button2.Location = new System.Drawing.Point(0, 0);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(191, 40);
            this.button2.TabIndex = 7;
            this.button2.Text = "Show";
            this.button2.UseVisualStyleBackColor = true;
            // 
            // panelOthersDown
            // 
            this.panelOthersDown.Controls.Add(this.button11);
            this.panelOthersDown.Controls.Add(this.button10);
            this.panelOthersDown.Controls.Add(this.btnTeamEditOrShow);
            this.panelOthersDown.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panelOthersDown.Location = new System.Drawing.Point(0, 690);
            this.panelOthersDown.Name = "panelOthersDown";
            this.panelOthersDown.Size = new System.Drawing.Size(191, 156);
            this.panelOthersDown.TabIndex = 6;
            // 
            // button11
            // 
            this.button11.Dock = System.Windows.Forms.DockStyle.Top;
            this.button11.Location = new System.Drawing.Point(0, 80);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(191, 40);
            this.button11.TabIndex = 2;
            this.button11.Text = "Help";
            this.button11.UseVisualStyleBackColor = true;
            // 
            // button10
            // 
            this.button10.Dock = System.Windows.Forms.DockStyle.Top;
            this.button10.Location = new System.Drawing.Point(0, 40);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(191, 40);
            this.button10.TabIndex = 1;
            this.button10.Text = "Accounts";
            this.button10.UseVisualStyleBackColor = true;
            // 
            // btnTeamEditOrShow
            // 
            this.btnTeamEditOrShow.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnTeamEditOrShow.Location = new System.Drawing.Point(0, 0);
            this.btnTeamEditOrShow.Name = "btnTeamEditOrShow";
            this.btnTeamEditOrShow.Size = new System.Drawing.Size(191, 40);
            this.btnTeamEditOrShow.TabIndex = 0;
            this.btnTeamEditOrShow.Text = "Team";
            this.btnTeamEditOrShow.UseVisualStyleBackColor = true;
            this.btnTeamEditOrShow.Click += new System.EventHandler(this.BtnTeamEditOrShow_Click);
            // 
            // btnOthersDown
            // 
            this.btnOthersDown.BackColor = System.Drawing.Color.Yellow;
            this.btnOthersDown.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnOthersDown.Location = new System.Drawing.Point(0, 480);
            this.btnOthersDown.Name = "btnOthersDown";
            this.btnOthersDown.Size = new System.Drawing.Size(191, 35);
            this.btnOthersDown.TabIndex = 5;
            this.btnOthersDown.Text = "President Details";
            this.btnOthersDown.UseVisualStyleBackColor = false;
            this.btnOthersDown.Click += new System.EventHandler(this.BtnOthersDown_Click);
            // 
            // panelStaff1Demo
            // 
            this.panelStaff1Demo.Controls.Add(this.btnCoachUpdateOrDelete);
            this.panelStaff1Demo.Controls.Add(this.btnAddCourseByAdmin);
            this.panelStaff1Demo.Controls.Add(this.buttonSeeCoach);
            this.panelStaff1Demo.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelStaff1Demo.Location = new System.Drawing.Point(0, 348);
            this.panelStaff1Demo.Name = "panelStaff1Demo";
            this.panelStaff1Demo.Size = new System.Drawing.Size(191, 132);
            this.panelStaff1Demo.TabIndex = 4;
            // 
            // btnCoachUpdateOrDelete
            // 
            this.btnCoachUpdateOrDelete.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnCoachUpdateOrDelete.Location = new System.Drawing.Point(0, 80);
            this.btnCoachUpdateOrDelete.Name = "btnCoachUpdateOrDelete";
            this.btnCoachUpdateOrDelete.Size = new System.Drawing.Size(191, 40);
            this.btnCoachUpdateOrDelete.TabIndex = 2;
            this.btnCoachUpdateOrDelete.Text = "Change or Update";
            this.btnCoachUpdateOrDelete.UseVisualStyleBackColor = true;
            this.btnCoachUpdateOrDelete.Click += new System.EventHandler(this.BtnCoachUpdateOrDelete_Click);
            // 
            // btnAddCourseByAdmin
            // 
            this.btnAddCourseByAdmin.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnAddCourseByAdmin.Location = new System.Drawing.Point(0, 40);
            this.btnAddCourseByAdmin.Name = "btnAddCourseByAdmin";
            this.btnAddCourseByAdmin.Size = new System.Drawing.Size(191, 40);
            this.btnAddCourseByAdmin.TabIndex = 1;
            this.btnAddCourseByAdmin.Text = "Add New";
            this.btnAddCourseByAdmin.UseVisualStyleBackColor = true;
            this.btnAddCourseByAdmin.Click += new System.EventHandler(this.BtnAddCourseByAdmin_Click);
            // 
            // buttonSeeCoach
            // 
            this.buttonSeeCoach.Dock = System.Windows.Forms.DockStyle.Top;
            this.buttonSeeCoach.Location = new System.Drawing.Point(0, 0);
            this.buttonSeeCoach.Name = "buttonSeeCoach";
            this.buttonSeeCoach.Size = new System.Drawing.Size(191, 40);
            this.buttonSeeCoach.TabIndex = 0;
            this.buttonSeeCoach.Text = "See";
            this.buttonSeeCoach.UseVisualStyleBackColor = true;
            this.buttonSeeCoach.Click += new System.EventHandler(this.ButtonSeeCoach_Click);
            // 
            // btnStaffDemo1
            // 
            this.btnStaffDemo1.BackColor = System.Drawing.Color.Maroon;
            this.btnStaffDemo1.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnStaffDemo1.Location = new System.Drawing.Point(0, 308);
            this.btnStaffDemo1.Name = "btnStaffDemo1";
            this.btnStaffDemo1.Size = new System.Drawing.Size(191, 40);
            this.btnStaffDemo1.TabIndex = 3;
            this.btnStaffDemo1.Text = "Coach";
            this.btnStaffDemo1.UseVisualStyleBackColor = false;
            this.btnStaffDemo1.Click += new System.EventHandler(this.BtnStaffDemo1_Click);
            // 
            // panelDown1SubMenu
            // 
            this.panelDown1SubMenu.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.panelDown1SubMenu.Controls.Add(this.button1);
            this.panelDown1SubMenu.Controls.Add(this.button4);
            this.panelDown1SubMenu.Controls.Add(this.btnRegistrationDemo);
            this.panelDown1SubMenu.Controls.Add(this.btnPlayerSeeAll);
            this.panelDown1SubMenu.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelDown1SubMenu.Location = new System.Drawing.Point(0, 142);
            this.panelDown1SubMenu.Name = "panelDown1SubMenu";
            this.panelDown1SubMenu.Size = new System.Drawing.Size(191, 166);
            this.panelDown1SubMenu.TabIndex = 2;
            // 
            // button1
            // 
            this.button1.Dock = System.Windows.Forms.DockStyle.Top;
            this.button1.Location = new System.Drawing.Point(0, 123);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(191, 43);
            this.button1.TabIndex = 3;
            this.button1.Text = "Delete";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // button4
            // 
            this.button4.Dock = System.Windows.Forms.DockStyle.Top;
            this.button4.Location = new System.Drawing.Point(0, 83);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(191, 40);
            this.button4.TabIndex = 2;
            this.button4.Text = "Change and Update";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.Button4_Click);
            // 
            // btnRegistrationDemo
            // 
            this.btnRegistrationDemo.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnRegistrationDemo.Location = new System.Drawing.Point(0, 43);
            this.btnRegistrationDemo.Name = "btnRegistrationDemo";
            this.btnRegistrationDemo.Size = new System.Drawing.Size(191, 40);
            this.btnRegistrationDemo.TabIndex = 1;
            this.btnRegistrationDemo.Text = "Registration";
            this.btnRegistrationDemo.UseVisualStyleBackColor = true;
            this.btnRegistrationDemo.Click += new System.EventHandler(this.BtnRegistrationDemo_Click);
            // 
            // btnPlayerSeeAll
            // 
            this.btnPlayerSeeAll.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnPlayerSeeAll.Location = new System.Drawing.Point(0, 0);
            this.btnPlayerSeeAll.Name = "btnPlayerSeeAll";
            this.btnPlayerSeeAll.Size = new System.Drawing.Size(191, 43);
            this.btnPlayerSeeAll.TabIndex = 0;
            this.btnPlayerSeeAll.Text = "See all";
            this.btnPlayerSeeAll.UseVisualStyleBackColor = true;
            this.btnPlayerSeeAll.Click += new System.EventHandler(this.Button2_Click);
            // 
            // btnDown1
            // 
            this.btnDown1.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnDown1.FlatAppearance.BorderSize = 0;
            this.btnDown1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDown1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnDown1.Location = new System.Drawing.Point(0, 102);
            this.btnDown1.Name = "btnDown1";
            this.btnDown1.Size = new System.Drawing.Size(191, 40);
            this.btnDown1.TabIndex = 1;
            this.btnDown1.Text = "Player";
            this.btnDown1.UseVisualStyleBackColor = true;
            this.btnDown1.Click += new System.EventHandler(this.BtnDown1_Click);
            // 
            // panelLogo
            // 
            this.panelLogo.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelLogo.Location = new System.Drawing.Point(0, 0);
            this.panelLogo.Name = "panelLogo";
            this.panelLogo.Size = new System.Drawing.Size(191, 102);
            this.panelLogo.TabIndex = 0;
            // 
            // panelChild1DashBoardAdmin
            // 
            this.panelChild1DashBoardAdmin.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.panelChild1DashBoardAdmin.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelChild1DashBoardAdmin.Location = new System.Drawing.Point(208, 0);
            this.panelChild1DashBoardAdmin.Name = "panelChild1DashBoardAdmin";
            this.panelChild1DashBoardAdmin.Size = new System.Drawing.Size(582, 509);
            this.panelChild1DashBoardAdmin.TabIndex = 1;
            // 
            // DashBoardAdmin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.ClientSize = new System.Drawing.Size(790, 509);
            this.Controls.Add(this.panelChild1DashBoardAdmin);
            this.Controls.Add(this.panelSideMenu);
            this.Name = "DashBoardAdmin";
            this.Text = "DashBoardAdmin";
            this.Load += new System.EventHandler(this.DashBoardAdmin_Load);
            this.panelSideMenu.ResumeLayout(false);
            this.panelPresidentsDemo.ResumeLayout(false);
            this.panelOthersDown.ResumeLayout(false);
            this.panelStaff1Demo.ResumeLayout(false);
            this.panelDown1SubMenu.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panelSideMenu;
        private System.Windows.Forms.Panel panelDown1SubMenu;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button btnRegistrationDemo;
        private System.Windows.Forms.Button btnPlayerSeeAll;
        private System.Windows.Forms.Button btnDown1;
        private System.Windows.Forms.Panel panelLogo;
        private System.Windows.Forms.Panel panelChild1DashBoardAdmin;
        private System.Windows.Forms.Panel panelStaff1Demo;
        private System.Windows.Forms.Button btnCoachUpdateOrDelete;
        private System.Windows.Forms.Button btnAddCourseByAdmin;
        private System.Windows.Forms.Button buttonSeeCoach;
        private System.Windows.Forms.Button btnStaffDemo1;
        private System.Windows.Forms.Panel panelOthersDown;
        private System.Windows.Forms.Button btnOthersDown;
        private System.Windows.Forms.Button btnOtherNewDown;
        private System.Windows.Forms.Panel panelPresidentsDemo;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.Button btnTeamEditOrShow;
    }
}