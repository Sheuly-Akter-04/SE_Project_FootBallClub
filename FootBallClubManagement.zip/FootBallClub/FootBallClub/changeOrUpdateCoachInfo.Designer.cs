﻿namespace FootBallClub
{
    partial class changeOrUpdateCoachInfo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.roundButton1 = new FootBallClub.RoundButton();
            this.btnDeleteCoachInfo = new MaterialSkin.Controls.MaterialRaisedButton();
            this.btnUpdateCoachInfo = new MaterialSkin.Controls.MaterialRaisedButton();
            this.dataGridViewchangeOrUpdateCoachInfo = new System.Windows.Forms.DataGridView();
            this.txtNamechangeOrUpdateCoachInfo = new MaterialSkin.Controls.MaterialSingleLineTextField();
            this.txtBirthdaychangeOrUpdateCoachInfo = new MaterialSkin.Controls.MaterialSingleLineTextField();
            this.txtEmailchangeOrUpdateCoachInfo = new MaterialSkin.Controls.MaterialSingleLineTextField();
            this.txtHeightchangeOrUpdateCoachInfo = new MaterialSkin.Controls.MaterialSingleLineTextField();
            this.txtPasswordchangeOrUpdateCoachInfo = new MaterialSkin.Controls.MaterialSingleLineTextField();
            this.txtPhonechangeOrUpdateCoachInfo = new MaterialSkin.Controls.MaterialSingleLineTextField();
            this.txtWeightchangeOrUpdateCoachInfo = new MaterialSkin.Controls.MaterialSingleLineTextField();
            this.label1 = new System.Windows.Forms.Label();
            this.rbBtnMalechangeOrUpdateCoachInfo = new System.Windows.Forms.RadioButton();
            this.rbBtnFemalechangeOrUpdateCoachInfo = new System.Windows.Forms.RadioButton();
            this.comboBoxNationaliltychangeOrUpdateCoachInfo = new System.Windows.Forms.ComboBox();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewchangeOrUpdateCoachInfo)).BeginInit();
            this.SuspendLayout();
            // 
            // roundButton1
            // 
            this.roundButton1.Location = new System.Drawing.Point(12, 12);
            this.roundButton1.Name = "roundButton1";
            this.roundButton1.Size = new System.Drawing.Size(53, 38);
            this.roundButton1.TabIndex = 0;
            this.roundButton1.Text = "<";
            this.roundButton1.UseVisualStyleBackColor = true;
            // 
            // btnDeleteCoachInfo
            // 
            this.btnDeleteCoachInfo.Depth = 0;
            this.btnDeleteCoachInfo.Location = new System.Drawing.Point(455, 353);
            this.btnDeleteCoachInfo.MouseState = MaterialSkin.MouseState.HOVER;
            this.btnDeleteCoachInfo.Name = "btnDeleteCoachInfo";
            this.btnDeleteCoachInfo.Primary = true;
            this.btnDeleteCoachInfo.Size = new System.Drawing.Size(75, 55);
            this.btnDeleteCoachInfo.TabIndex = 2;
            this.btnDeleteCoachInfo.Text = "Delete";
            this.btnDeleteCoachInfo.UseVisualStyleBackColor = true;
            // 
            // btnUpdateCoachInfo
            // 
            this.btnUpdateCoachInfo.Depth = 0;
            this.btnUpdateCoachInfo.Location = new System.Drawing.Point(455, 266);
            this.btnUpdateCoachInfo.MouseState = MaterialSkin.MouseState.HOVER;
            this.btnUpdateCoachInfo.Name = "btnUpdateCoachInfo";
            this.btnUpdateCoachInfo.Primary = true;
            this.btnUpdateCoachInfo.Size = new System.Drawing.Size(75, 54);
            this.btnUpdateCoachInfo.TabIndex = 2;
            this.btnUpdateCoachInfo.Text = "Update";
            this.btnUpdateCoachInfo.UseVisualStyleBackColor = true;
            this.btnUpdateCoachInfo.Click += new System.EventHandler(this.BtnUpdateCoachInfo_Click);
            // 
            // dataGridViewchangeOrUpdateCoachInfo
            // 
            this.dataGridViewchangeOrUpdateCoachInfo.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewchangeOrUpdateCoachInfo.Location = new System.Drawing.Point(22, 68);
            this.dataGridViewchangeOrUpdateCoachInfo.Name = "dataGridViewchangeOrUpdateCoachInfo";
            this.dataGridViewchangeOrUpdateCoachInfo.Size = new System.Drawing.Size(520, 113);
            this.dataGridViewchangeOrUpdateCoachInfo.TabIndex = 3;
            this.dataGridViewchangeOrUpdateCoachInfo.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.DataGridViewchangeOrUpdateCoachInfo_CellContentClick);
            // 
            // txtNamechangeOrUpdateCoachInfo
            // 
            this.txtNamechangeOrUpdateCoachInfo.Depth = 0;
            this.txtNamechangeOrUpdateCoachInfo.Hint = "";
            this.txtNamechangeOrUpdateCoachInfo.Location = new System.Drawing.Point(22, 197);
            this.txtNamechangeOrUpdateCoachInfo.MouseState = MaterialSkin.MouseState.HOVER;
            this.txtNamechangeOrUpdateCoachInfo.Name = "txtNamechangeOrUpdateCoachInfo";
            this.txtNamechangeOrUpdateCoachInfo.PasswordChar = '\0';
            this.txtNamechangeOrUpdateCoachInfo.SelectedText = "";
            this.txtNamechangeOrUpdateCoachInfo.SelectionLength = 0;
            this.txtNamechangeOrUpdateCoachInfo.SelectionStart = 0;
            this.txtNamechangeOrUpdateCoachInfo.Size = new System.Drawing.Size(299, 23);
            this.txtNamechangeOrUpdateCoachInfo.TabIndex = 4;
            this.txtNamechangeOrUpdateCoachInfo.Text = "Full Name";
            this.txtNamechangeOrUpdateCoachInfo.UseSystemPasswordChar = false;
            // 
            // txtBirthdaychangeOrUpdateCoachInfo
            // 
            this.txtBirthdaychangeOrUpdateCoachInfo.Depth = 0;
            this.txtBirthdaychangeOrUpdateCoachInfo.Hint = "";
            this.txtBirthdaychangeOrUpdateCoachInfo.Location = new System.Drawing.Point(22, 236);
            this.txtBirthdaychangeOrUpdateCoachInfo.MouseState = MaterialSkin.MouseState.HOVER;
            this.txtBirthdaychangeOrUpdateCoachInfo.Name = "txtBirthdaychangeOrUpdateCoachInfo";
            this.txtBirthdaychangeOrUpdateCoachInfo.PasswordChar = '\0';
            this.txtBirthdaychangeOrUpdateCoachInfo.SelectedText = "";
            this.txtBirthdaychangeOrUpdateCoachInfo.SelectionLength = 0;
            this.txtBirthdaychangeOrUpdateCoachInfo.SelectionStart = 0;
            this.txtBirthdaychangeOrUpdateCoachInfo.Size = new System.Drawing.Size(299, 23);
            this.txtBirthdaychangeOrUpdateCoachInfo.TabIndex = 4;
            this.txtBirthdaychangeOrUpdateCoachInfo.Text = "Birthday";
            this.txtBirthdaychangeOrUpdateCoachInfo.UseSystemPasswordChar = false;
            // 
            // txtEmailchangeOrUpdateCoachInfo
            // 
            this.txtEmailchangeOrUpdateCoachInfo.Depth = 0;
            this.txtEmailchangeOrUpdateCoachInfo.Hint = "";
            this.txtEmailchangeOrUpdateCoachInfo.Location = new System.Drawing.Point(22, 297);
            this.txtEmailchangeOrUpdateCoachInfo.MouseState = MaterialSkin.MouseState.HOVER;
            this.txtEmailchangeOrUpdateCoachInfo.Name = "txtEmailchangeOrUpdateCoachInfo";
            this.txtEmailchangeOrUpdateCoachInfo.PasswordChar = '\0';
            this.txtEmailchangeOrUpdateCoachInfo.SelectedText = "";
            this.txtEmailchangeOrUpdateCoachInfo.SelectionLength = 0;
            this.txtEmailchangeOrUpdateCoachInfo.SelectionStart = 0;
            this.txtEmailchangeOrUpdateCoachInfo.Size = new System.Drawing.Size(299, 23);
            this.txtEmailchangeOrUpdateCoachInfo.TabIndex = 4;
            this.txtEmailchangeOrUpdateCoachInfo.Text = "Email";
            this.txtEmailchangeOrUpdateCoachInfo.UseSystemPasswordChar = false;
            // 
            // txtHeightchangeOrUpdateCoachInfo
            // 
            this.txtHeightchangeOrUpdateCoachInfo.Depth = 0;
            this.txtHeightchangeOrUpdateCoachInfo.Hint = "";
            this.txtHeightchangeOrUpdateCoachInfo.Location = new System.Drawing.Point(22, 353);
            this.txtHeightchangeOrUpdateCoachInfo.MouseState = MaterialSkin.MouseState.HOVER;
            this.txtHeightchangeOrUpdateCoachInfo.Name = "txtHeightchangeOrUpdateCoachInfo";
            this.txtHeightchangeOrUpdateCoachInfo.PasswordChar = '\0';
            this.txtHeightchangeOrUpdateCoachInfo.SelectedText = "";
            this.txtHeightchangeOrUpdateCoachInfo.SelectionLength = 0;
            this.txtHeightchangeOrUpdateCoachInfo.SelectionStart = 0;
            this.txtHeightchangeOrUpdateCoachInfo.Size = new System.Drawing.Size(299, 23);
            this.txtHeightchangeOrUpdateCoachInfo.TabIndex = 4;
            this.txtHeightchangeOrUpdateCoachInfo.Text = "Height";
            this.txtHeightchangeOrUpdateCoachInfo.UseSystemPasswordChar = false;
            // 
            // txtPasswordchangeOrUpdateCoachInfo
            // 
            this.txtPasswordchangeOrUpdateCoachInfo.Depth = 0;
            this.txtPasswordchangeOrUpdateCoachInfo.Hint = "";
            this.txtPasswordchangeOrUpdateCoachInfo.Location = new System.Drawing.Point(22, 441);
            this.txtPasswordchangeOrUpdateCoachInfo.MouseState = MaterialSkin.MouseState.HOVER;
            this.txtPasswordchangeOrUpdateCoachInfo.Name = "txtPasswordchangeOrUpdateCoachInfo";
            this.txtPasswordchangeOrUpdateCoachInfo.PasswordChar = '\0';
            this.txtPasswordchangeOrUpdateCoachInfo.SelectedText = "";
            this.txtPasswordchangeOrUpdateCoachInfo.SelectionLength = 0;
            this.txtPasswordchangeOrUpdateCoachInfo.SelectionStart = 0;
            this.txtPasswordchangeOrUpdateCoachInfo.Size = new System.Drawing.Size(299, 23);
            this.txtPasswordchangeOrUpdateCoachInfo.TabIndex = 4;
            this.txtPasswordchangeOrUpdateCoachInfo.Text = "Password";
            this.txtPasswordchangeOrUpdateCoachInfo.UseSystemPasswordChar = false;
            // 
            // txtPhonechangeOrUpdateCoachInfo
            // 
            this.txtPhonechangeOrUpdateCoachInfo.Depth = 0;
            this.txtPhonechangeOrUpdateCoachInfo.Hint = "";
            this.txtPhonechangeOrUpdateCoachInfo.Location = new System.Drawing.Point(22, 326);
            this.txtPhonechangeOrUpdateCoachInfo.MouseState = MaterialSkin.MouseState.HOVER;
            this.txtPhonechangeOrUpdateCoachInfo.Name = "txtPhonechangeOrUpdateCoachInfo";
            this.txtPhonechangeOrUpdateCoachInfo.PasswordChar = '\0';
            this.txtPhonechangeOrUpdateCoachInfo.SelectedText = "";
            this.txtPhonechangeOrUpdateCoachInfo.SelectionLength = 0;
            this.txtPhonechangeOrUpdateCoachInfo.SelectionStart = 0;
            this.txtPhonechangeOrUpdateCoachInfo.Size = new System.Drawing.Size(299, 23);
            this.txtPhonechangeOrUpdateCoachInfo.TabIndex = 4;
            this.txtPhonechangeOrUpdateCoachInfo.Text = "Phone";
            this.txtPhonechangeOrUpdateCoachInfo.UseSystemPasswordChar = false;
            // 
            // txtWeightchangeOrUpdateCoachInfo
            // 
            this.txtWeightchangeOrUpdateCoachInfo.Depth = 0;
            this.txtWeightchangeOrUpdateCoachInfo.Hint = "";
            this.txtWeightchangeOrUpdateCoachInfo.Location = new System.Drawing.Point(22, 385);
            this.txtWeightchangeOrUpdateCoachInfo.MouseState = MaterialSkin.MouseState.HOVER;
            this.txtWeightchangeOrUpdateCoachInfo.Name = "txtWeightchangeOrUpdateCoachInfo";
            this.txtWeightchangeOrUpdateCoachInfo.PasswordChar = '\0';
            this.txtWeightchangeOrUpdateCoachInfo.SelectedText = "";
            this.txtWeightchangeOrUpdateCoachInfo.SelectionLength = 0;
            this.txtWeightchangeOrUpdateCoachInfo.SelectionStart = 0;
            this.txtWeightchangeOrUpdateCoachInfo.Size = new System.Drawing.Size(299, 23);
            this.txtWeightchangeOrUpdateCoachInfo.TabIndex = 4;
            this.txtWeightchangeOrUpdateCoachInfo.Text = "Weight";
            this.txtWeightchangeOrUpdateCoachInfo.UseSystemPasswordChar = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(22, 266);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(42, 13);
            this.label1.TabIndex = 5;
            this.label1.Text = "Gender";
            // 
            // rbBtnMalechangeOrUpdateCoachInfo
            // 
            this.rbBtnMalechangeOrUpdateCoachInfo.AutoSize = true;
            this.rbBtnMalechangeOrUpdateCoachInfo.Location = new System.Drawing.Point(111, 266);
            this.rbBtnMalechangeOrUpdateCoachInfo.Name = "rbBtnMalechangeOrUpdateCoachInfo";
            this.rbBtnMalechangeOrUpdateCoachInfo.Size = new System.Drawing.Size(48, 17);
            this.rbBtnMalechangeOrUpdateCoachInfo.TabIndex = 6;
            this.rbBtnMalechangeOrUpdateCoachInfo.TabStop = true;
            this.rbBtnMalechangeOrUpdateCoachInfo.Text = "Male";
            this.rbBtnMalechangeOrUpdateCoachInfo.UseVisualStyleBackColor = true;
            // 
            // rbBtnFemalechangeOrUpdateCoachInfo
            // 
            this.rbBtnFemalechangeOrUpdateCoachInfo.AutoSize = true;
            this.rbBtnFemalechangeOrUpdateCoachInfo.Location = new System.Drawing.Point(224, 266);
            this.rbBtnFemalechangeOrUpdateCoachInfo.Name = "rbBtnFemalechangeOrUpdateCoachInfo";
            this.rbBtnFemalechangeOrUpdateCoachInfo.Size = new System.Drawing.Size(59, 17);
            this.rbBtnFemalechangeOrUpdateCoachInfo.TabIndex = 6;
            this.rbBtnFemalechangeOrUpdateCoachInfo.TabStop = true;
            this.rbBtnFemalechangeOrUpdateCoachInfo.Text = "Female";
            this.rbBtnFemalechangeOrUpdateCoachInfo.UseVisualStyleBackColor = true;
            // 
            // comboBoxNationaliltychangeOrUpdateCoachInfo
            // 
            this.comboBoxNationaliltychangeOrUpdateCoachInfo.FormattingEnabled = true;
            this.comboBoxNationaliltychangeOrUpdateCoachInfo.Location = new System.Drawing.Point(22, 414);
            this.comboBoxNationaliltychangeOrUpdateCoachInfo.Name = "comboBoxNationaliltychangeOrUpdateCoachInfo";
            this.comboBoxNationaliltychangeOrUpdateCoachInfo.Size = new System.Drawing.Size(299, 21);
            this.comboBoxNationaliltychangeOrUpdateCoachInfo.TabIndex = 7;
            this.comboBoxNationaliltychangeOrUpdateCoachInfo.Text = "Nationality";
            // 
            // changeOrUpdateCoachInfo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(566, 470);
            this.Controls.Add(this.comboBoxNationaliltychangeOrUpdateCoachInfo);
            this.Controls.Add(this.rbBtnFemalechangeOrUpdateCoachInfo);
            this.Controls.Add(this.rbBtnMalechangeOrUpdateCoachInfo);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtPasswordchangeOrUpdateCoachInfo);
            this.Controls.Add(this.txtWeightchangeOrUpdateCoachInfo);
            this.Controls.Add(this.txtPhonechangeOrUpdateCoachInfo);
            this.Controls.Add(this.txtHeightchangeOrUpdateCoachInfo);
            this.Controls.Add(this.txtEmailchangeOrUpdateCoachInfo);
            this.Controls.Add(this.txtBirthdaychangeOrUpdateCoachInfo);
            this.Controls.Add(this.txtNamechangeOrUpdateCoachInfo);
            this.Controls.Add(this.dataGridViewchangeOrUpdateCoachInfo);
            this.Controls.Add(this.btnUpdateCoachInfo);
            this.Controls.Add(this.btnDeleteCoachInfo);
            this.Controls.Add(this.roundButton1);
            this.Name = "changeOrUpdateCoachInfo";
            this.Text = "changeOrUpdateCoachInfo";
            this.Load += new System.EventHandler(this.ChangeOrUpdateCoachInfo_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewchangeOrUpdateCoachInfo)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private RoundButton roundButton1;
        private MaterialSkin.Controls.MaterialRaisedButton btnDeleteCoachInfo;
        private MaterialSkin.Controls.MaterialRaisedButton btnUpdateCoachInfo;
        private System.Windows.Forms.DataGridView dataGridViewchangeOrUpdateCoachInfo;
        private MaterialSkin.Controls.MaterialSingleLineTextField txtNamechangeOrUpdateCoachInfo;
        private MaterialSkin.Controls.MaterialSingleLineTextField txtBirthdaychangeOrUpdateCoachInfo;
        private MaterialSkin.Controls.MaterialSingleLineTextField txtEmailchangeOrUpdateCoachInfo;
        private MaterialSkin.Controls.MaterialSingleLineTextField txtHeightchangeOrUpdateCoachInfo;
        private MaterialSkin.Controls.MaterialSingleLineTextField txtPasswordchangeOrUpdateCoachInfo;
        private MaterialSkin.Controls.MaterialSingleLineTextField txtPhonechangeOrUpdateCoachInfo;
        private MaterialSkin.Controls.MaterialSingleLineTextField txtWeightchangeOrUpdateCoachInfo;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.RadioButton rbBtnMalechangeOrUpdateCoachInfo;
        private System.Windows.Forms.RadioButton rbBtnFemalechangeOrUpdateCoachInfo;
        private System.Windows.Forms.ComboBox comboBoxNationaliltychangeOrUpdateCoachInfo;
    }
}