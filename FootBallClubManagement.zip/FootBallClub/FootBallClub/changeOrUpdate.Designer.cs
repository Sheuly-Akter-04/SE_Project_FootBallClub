﻿namespace FootBallClub
{
    partial class changeOrUpdate
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnDeletePlayerChangeOrUpdate = new MaterialSkin.Controls.MaterialRaisedButton();
            this.btnUpdatePlayerChangeOrUpdate = new MaterialSkin.Controls.MaterialRaisedButton();
            this.txtWeightPlayerChangeOrUpdate = new MaterialSkin.Controls.MaterialSingleLineTextField();
            this.txtHeightPlayerChangeOrUpdate = new MaterialSkin.Controls.MaterialSingleLineTextField();
            this.txtBirthdayPlayerChangeOrUpdate = new MaterialSkin.Controls.MaterialSingleLineTextField();
            this.txtPhonePlayerChangeOrUpdate = new MaterialSkin.Controls.MaterialSingleLineTextField();
            this.txtEmailPlayerChangeOrUpdate = new MaterialSkin.Controls.MaterialSingleLineTextField();
            this.txtNamePlayerChangeOrUpdate = new MaterialSkin.Controls.MaterialSingleLineTextField();
            this.label2 = new System.Windows.Forms.Label();
            this.dataGridViewChangeOrUpdatePlayer = new System.Windows.Forms.DataGridView();
            this.roundButton1 = new FootBallClub.RoundButton();
            this.label1 = new System.Windows.Forms.Label();
            this.rbBtnMalePlayerChangeOrUpdate = new System.Windows.Forms.RadioButton();
            this.rbBtnFemalePlayerChangeOrUpdate = new System.Windows.Forms.RadioButton();
            this.txtNationalitylayerChangeOrUpdate = new MaterialSkin.Controls.MaterialSingleLineTextField();
            this.txtPasswordlayerChangeOrUpdate = new MaterialSkin.Controls.MaterialSingleLineTextField();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewChangeOrUpdatePlayer)).BeginInit();
            this.SuspendLayout();
            // 
            // btnDeletePlayerChangeOrUpdate
            // 
            this.btnDeletePlayerChangeOrUpdate.Depth = 0;
            this.btnDeletePlayerChangeOrUpdate.Location = new System.Drawing.Point(413, 405);
            this.btnDeletePlayerChangeOrUpdate.MouseState = MaterialSkin.MouseState.HOVER;
            this.btnDeletePlayerChangeOrUpdate.Name = "btnDeletePlayerChangeOrUpdate";
            this.btnDeletePlayerChangeOrUpdate.Primary = true;
            this.btnDeletePlayerChangeOrUpdate.Size = new System.Drawing.Size(126, 58);
            this.btnDeletePlayerChangeOrUpdate.TabIndex = 14;
            this.btnDeletePlayerChangeOrUpdate.Text = "Delete";
            this.btnDeletePlayerChangeOrUpdate.UseVisualStyleBackColor = true;
            // 
            // btnUpdatePlayerChangeOrUpdate
            // 
            this.btnUpdatePlayerChangeOrUpdate.Depth = 0;
            this.btnUpdatePlayerChangeOrUpdate.Location = new System.Drawing.Point(413, 254);
            this.btnUpdatePlayerChangeOrUpdate.MouseState = MaterialSkin.MouseState.HOVER;
            this.btnUpdatePlayerChangeOrUpdate.Name = "btnUpdatePlayerChangeOrUpdate";
            this.btnUpdatePlayerChangeOrUpdate.Primary = true;
            this.btnUpdatePlayerChangeOrUpdate.Size = new System.Drawing.Size(126, 86);
            this.btnUpdatePlayerChangeOrUpdate.TabIndex = 15;
            this.btnUpdatePlayerChangeOrUpdate.Text = "Update";
            this.btnUpdatePlayerChangeOrUpdate.UseVisualStyleBackColor = true;
            this.btnUpdatePlayerChangeOrUpdate.Click += new System.EventHandler(this.BtnUpdatePlayerChangeOrUpdate_Click);
            // 
            // txtWeightPlayerChangeOrUpdate
            // 
            this.txtWeightPlayerChangeOrUpdate.Depth = 0;
            this.txtWeightPlayerChangeOrUpdate.Hint = "";
            this.txtWeightPlayerChangeOrUpdate.Location = new System.Drawing.Point(40, 383);
            this.txtWeightPlayerChangeOrUpdate.MouseState = MaterialSkin.MouseState.HOVER;
            this.txtWeightPlayerChangeOrUpdate.Name = "txtWeightPlayerChangeOrUpdate";
            this.txtWeightPlayerChangeOrUpdate.PasswordChar = '\0';
            this.txtWeightPlayerChangeOrUpdate.SelectedText = "";
            this.txtWeightPlayerChangeOrUpdate.SelectionLength = 0;
            this.txtWeightPlayerChangeOrUpdate.SelectionStart = 0;
            this.txtWeightPlayerChangeOrUpdate.Size = new System.Drawing.Size(284, 23);
            this.txtWeightPlayerChangeOrUpdate.TabIndex = 8;
            this.txtWeightPlayerChangeOrUpdate.Text = "Weight";
            this.txtWeightPlayerChangeOrUpdate.UseSystemPasswordChar = false;
            // 
            // txtHeightPlayerChangeOrUpdate
            // 
            this.txtHeightPlayerChangeOrUpdate.Depth = 0;
            this.txtHeightPlayerChangeOrUpdate.Hint = "";
            this.txtHeightPlayerChangeOrUpdate.Location = new System.Drawing.Point(40, 349);
            this.txtHeightPlayerChangeOrUpdate.MouseState = MaterialSkin.MouseState.HOVER;
            this.txtHeightPlayerChangeOrUpdate.Name = "txtHeightPlayerChangeOrUpdate";
            this.txtHeightPlayerChangeOrUpdate.PasswordChar = '\0';
            this.txtHeightPlayerChangeOrUpdate.SelectedText = "";
            this.txtHeightPlayerChangeOrUpdate.SelectionLength = 0;
            this.txtHeightPlayerChangeOrUpdate.SelectionStart = 0;
            this.txtHeightPlayerChangeOrUpdate.Size = new System.Drawing.Size(284, 23);
            this.txtHeightPlayerChangeOrUpdate.TabIndex = 9;
            this.txtHeightPlayerChangeOrUpdate.Text = "Height";
            this.txtHeightPlayerChangeOrUpdate.UseSystemPasswordChar = false;
            // 
            // txtBirthdayPlayerChangeOrUpdate
            // 
            this.txtBirthdayPlayerChangeOrUpdate.Depth = 0;
            this.txtBirthdayPlayerChangeOrUpdate.Hint = "";
            this.txtBirthdayPlayerChangeOrUpdate.Location = new System.Drawing.Point(40, 213);
            this.txtBirthdayPlayerChangeOrUpdate.MouseState = MaterialSkin.MouseState.HOVER;
            this.txtBirthdayPlayerChangeOrUpdate.Name = "txtBirthdayPlayerChangeOrUpdate";
            this.txtBirthdayPlayerChangeOrUpdate.PasswordChar = '\0';
            this.txtBirthdayPlayerChangeOrUpdate.SelectedText = "";
            this.txtBirthdayPlayerChangeOrUpdate.SelectionLength = 0;
            this.txtBirthdayPlayerChangeOrUpdate.SelectionStart = 0;
            this.txtBirthdayPlayerChangeOrUpdate.Size = new System.Drawing.Size(284, 23);
            this.txtBirthdayPlayerChangeOrUpdate.TabIndex = 10;
            this.txtBirthdayPlayerChangeOrUpdate.Text = "Birthday";
            this.txtBirthdayPlayerChangeOrUpdate.UseSystemPasswordChar = false;
            // 
            // txtPhonePlayerChangeOrUpdate
            // 
            this.txtPhonePlayerChangeOrUpdate.Depth = 0;
            this.txtPhonePlayerChangeOrUpdate.Hint = "";
            this.txtPhonePlayerChangeOrUpdate.Location = new System.Drawing.Point(40, 317);
            this.txtPhonePlayerChangeOrUpdate.MouseState = MaterialSkin.MouseState.HOVER;
            this.txtPhonePlayerChangeOrUpdate.Name = "txtPhonePlayerChangeOrUpdate";
            this.txtPhonePlayerChangeOrUpdate.PasswordChar = '\0';
            this.txtPhonePlayerChangeOrUpdate.SelectedText = "";
            this.txtPhonePlayerChangeOrUpdate.SelectionLength = 0;
            this.txtPhonePlayerChangeOrUpdate.SelectionStart = 0;
            this.txtPhonePlayerChangeOrUpdate.Size = new System.Drawing.Size(284, 23);
            this.txtPhonePlayerChangeOrUpdate.TabIndex = 11;
            this.txtPhonePlayerChangeOrUpdate.Text = "Phone";
            this.txtPhonePlayerChangeOrUpdate.UseSystemPasswordChar = false;
            // 
            // txtEmailPlayerChangeOrUpdate
            // 
            this.txtEmailPlayerChangeOrUpdate.Depth = 0;
            this.txtEmailPlayerChangeOrUpdate.Hint = "";
            this.txtEmailPlayerChangeOrUpdate.Location = new System.Drawing.Point(40, 285);
            this.txtEmailPlayerChangeOrUpdate.MouseState = MaterialSkin.MouseState.HOVER;
            this.txtEmailPlayerChangeOrUpdate.Name = "txtEmailPlayerChangeOrUpdate";
            this.txtEmailPlayerChangeOrUpdate.PasswordChar = '\0';
            this.txtEmailPlayerChangeOrUpdate.SelectedText = "";
            this.txtEmailPlayerChangeOrUpdate.SelectionLength = 0;
            this.txtEmailPlayerChangeOrUpdate.SelectionStart = 0;
            this.txtEmailPlayerChangeOrUpdate.Size = new System.Drawing.Size(284, 23);
            this.txtEmailPlayerChangeOrUpdate.TabIndex = 12;
            this.txtEmailPlayerChangeOrUpdate.Text = "Email";
            this.txtEmailPlayerChangeOrUpdate.UseSystemPasswordChar = false;
            // 
            // txtNamePlayerChangeOrUpdate
            // 
            this.txtNamePlayerChangeOrUpdate.Depth = 0;
            this.txtNamePlayerChangeOrUpdate.Hint = "";
            this.txtNamePlayerChangeOrUpdate.Location = new System.Drawing.Point(40, 178);
            this.txtNamePlayerChangeOrUpdate.MouseState = MaterialSkin.MouseState.HOVER;
            this.txtNamePlayerChangeOrUpdate.Name = "txtNamePlayerChangeOrUpdate";
            this.txtNamePlayerChangeOrUpdate.PasswordChar = '\0';
            this.txtNamePlayerChangeOrUpdate.SelectedText = "";
            this.txtNamePlayerChangeOrUpdate.SelectionLength = 0;
            this.txtNamePlayerChangeOrUpdate.SelectionStart = 0;
            this.txtNamePlayerChangeOrUpdate.Size = new System.Drawing.Size(284, 23);
            this.txtNamePlayerChangeOrUpdate.TabIndex = 13;
            this.txtNamePlayerChangeOrUpdate.Text = "Full Name";
            this.txtNamePlayerChangeOrUpdate.UseSystemPasswordChar = false;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(31, 235);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(0, 13);
            this.label2.TabIndex = 6;
            // 
            // dataGridViewChangeOrUpdatePlayer
            // 
            this.dataGridViewChangeOrUpdatePlayer.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewChangeOrUpdatePlayer.Location = new System.Drawing.Point(12, 45);
            this.dataGridViewChangeOrUpdatePlayer.Name = "dataGridViewChangeOrUpdatePlayer";
            this.dataGridViewChangeOrUpdatePlayer.Size = new System.Drawing.Size(542, 129);
            this.dataGridViewChangeOrUpdatePlayer.TabIndex = 5;
            this.dataGridViewChangeOrUpdatePlayer.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.DataGridViewChangeOrUpdatePlayer_CellContentClick);
            // 
            // roundButton1
            // 
            this.roundButton1.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.roundButton1.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.roundButton1.FlatAppearance.BorderSize = 0;
            this.roundButton1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.roundButton1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.roundButton1.Location = new System.Drawing.Point(12, 8);
            this.roundButton1.Name = "roundButton1";
            this.roundButton1.Size = new System.Drawing.Size(39, 31);
            this.roundButton1.TabIndex = 7;
            this.roundButton1.Text = "<";
            this.roundButton1.UseVisualStyleBackColor = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(40, 254);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(42, 13);
            this.label1.TabIndex = 17;
            this.label1.Text = "Gender";
            // 
            // rbBtnMalePlayerChangeOrUpdate
            // 
            this.rbBtnMalePlayerChangeOrUpdate.AutoSize = true;
            this.rbBtnMalePlayerChangeOrUpdate.Location = new System.Drawing.Point(119, 256);
            this.rbBtnMalePlayerChangeOrUpdate.Name = "rbBtnMalePlayerChangeOrUpdate";
            this.rbBtnMalePlayerChangeOrUpdate.Size = new System.Drawing.Size(48, 17);
            this.rbBtnMalePlayerChangeOrUpdate.TabIndex = 18;
            this.rbBtnMalePlayerChangeOrUpdate.TabStop = true;
            this.rbBtnMalePlayerChangeOrUpdate.Text = "Male";
            this.rbBtnMalePlayerChangeOrUpdate.UseVisualStyleBackColor = true;
            // 
            // rbBtnFemalePlayerChangeOrUpdate
            // 
            this.rbBtnFemalePlayerChangeOrUpdate.AutoSize = true;
            this.rbBtnFemalePlayerChangeOrUpdate.Location = new System.Drawing.Point(232, 256);
            this.rbBtnFemalePlayerChangeOrUpdate.Name = "rbBtnFemalePlayerChangeOrUpdate";
            this.rbBtnFemalePlayerChangeOrUpdate.Size = new System.Drawing.Size(59, 17);
            this.rbBtnFemalePlayerChangeOrUpdate.TabIndex = 19;
            this.rbBtnFemalePlayerChangeOrUpdate.TabStop = true;
            this.rbBtnFemalePlayerChangeOrUpdate.Text = "Female";
            this.rbBtnFemalePlayerChangeOrUpdate.UseVisualStyleBackColor = true;
            // 
            // txtNationalitylayerChangeOrUpdate
            // 
            this.txtNationalitylayerChangeOrUpdate.Depth = 0;
            this.txtNationalitylayerChangeOrUpdate.Hint = "";
            this.txtNationalitylayerChangeOrUpdate.Location = new System.Drawing.Point(40, 412);
            this.txtNationalitylayerChangeOrUpdate.MouseState = MaterialSkin.MouseState.HOVER;
            this.txtNationalitylayerChangeOrUpdate.Name = "txtNationalitylayerChangeOrUpdate";
            this.txtNationalitylayerChangeOrUpdate.PasswordChar = '\0';
            this.txtNationalitylayerChangeOrUpdate.SelectedText = "";
            this.txtNationalitylayerChangeOrUpdate.SelectionLength = 0;
            this.txtNationalitylayerChangeOrUpdate.SelectionStart = 0;
            this.txtNationalitylayerChangeOrUpdate.Size = new System.Drawing.Size(284, 23);
            this.txtNationalitylayerChangeOrUpdate.TabIndex = 20;
            this.txtNationalitylayerChangeOrUpdate.Text = "Nationality";
            this.txtNationalitylayerChangeOrUpdate.UseSystemPasswordChar = false;
            this.txtNationalitylayerChangeOrUpdate.Click += new System.EventHandler(this.TxtNationalitylayerChangeOrUpdate_Click);
            // 
            // txtPasswordlayerChangeOrUpdate
            // 
            this.txtPasswordlayerChangeOrUpdate.Depth = 0;
            this.txtPasswordlayerChangeOrUpdate.Hint = "";
            this.txtPasswordlayerChangeOrUpdate.Location = new System.Drawing.Point(40, 441);
            this.txtPasswordlayerChangeOrUpdate.MouseState = MaterialSkin.MouseState.HOVER;
            this.txtPasswordlayerChangeOrUpdate.Name = "txtPasswordlayerChangeOrUpdate";
            this.txtPasswordlayerChangeOrUpdate.PasswordChar = '\0';
            this.txtPasswordlayerChangeOrUpdate.SelectedText = "";
            this.txtPasswordlayerChangeOrUpdate.SelectionLength = 0;
            this.txtPasswordlayerChangeOrUpdate.SelectionStart = 0;
            this.txtPasswordlayerChangeOrUpdate.Size = new System.Drawing.Size(284, 23);
            this.txtPasswordlayerChangeOrUpdate.TabIndex = 20;
            this.txtPasswordlayerChangeOrUpdate.Text = "Password";
            this.txtPasswordlayerChangeOrUpdate.UseSystemPasswordChar = false;
            // 
            // changeOrUpdate
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(566, 470);
            this.Controls.Add(this.txtPasswordlayerChangeOrUpdate);
            this.Controls.Add(this.txtNationalitylayerChangeOrUpdate);
            this.Controls.Add(this.rbBtnFemalePlayerChangeOrUpdate);
            this.Controls.Add(this.rbBtnMalePlayerChangeOrUpdate);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnDeletePlayerChangeOrUpdate);
            this.Controls.Add(this.btnUpdatePlayerChangeOrUpdate);
            this.Controls.Add(this.txtWeightPlayerChangeOrUpdate);
            this.Controls.Add(this.txtHeightPlayerChangeOrUpdate);
            this.Controls.Add(this.txtBirthdayPlayerChangeOrUpdate);
            this.Controls.Add(this.txtPhonePlayerChangeOrUpdate);
            this.Controls.Add(this.txtEmailPlayerChangeOrUpdate);
            this.Controls.Add(this.txtNamePlayerChangeOrUpdate);
            this.Controls.Add(this.roundButton1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.dataGridViewChangeOrUpdatePlayer);
            this.Name = "changeOrUpdate";
            this.Text = "Player change Or Update";
            this.Load += new System.EventHandler(this.ChangeOrUpdate_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewChangeOrUpdatePlayer)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private MaterialSkin.Controls.MaterialRaisedButton btnDeletePlayerChangeOrUpdate;
        private MaterialSkin.Controls.MaterialRaisedButton btnUpdatePlayerChangeOrUpdate;
        private MaterialSkin.Controls.MaterialSingleLineTextField txtWeightPlayerChangeOrUpdate;
        private MaterialSkin.Controls.MaterialSingleLineTextField txtHeightPlayerChangeOrUpdate;
        private MaterialSkin.Controls.MaterialSingleLineTextField txtBirthdayPlayerChangeOrUpdate;
        private MaterialSkin.Controls.MaterialSingleLineTextField txtPhonePlayerChangeOrUpdate;
        private MaterialSkin.Controls.MaterialSingleLineTextField txtEmailPlayerChangeOrUpdate;
        private MaterialSkin.Controls.MaterialSingleLineTextField txtNamePlayerChangeOrUpdate;
        private RoundButton roundButton1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.DataGridView dataGridViewChangeOrUpdatePlayer;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.RadioButton rbBtnMalePlayerChangeOrUpdate;
        private System.Windows.Forms.RadioButton rbBtnFemalePlayerChangeOrUpdate;
        private MaterialSkin.Controls.MaterialSingleLineTextField txtNationalitylayerChangeOrUpdate;
        private MaterialSkin.Controls.MaterialSingleLineTextField txtPasswordlayerChangeOrUpdate;
    }
}